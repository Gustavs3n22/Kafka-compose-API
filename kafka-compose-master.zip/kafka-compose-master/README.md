<p align="center">
    <div align="center">
        <h1>Kafka compose</h1>
        <p>
            <b>Простой запуск <a href="https://kafka.apache.org/uses">Kafka</a> </b>
        </p>
    </div>
</p>

Разворачивание максимально просто `docker-compose up`

В `localhost:8080` будет kowl, где удобно смотреть все про kafka

На `localhost:9092` будет сама кафка
