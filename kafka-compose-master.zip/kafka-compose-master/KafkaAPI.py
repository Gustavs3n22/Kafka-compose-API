from kafka import KafkaAdminClient, KafkaProducer, KafkaConsumer
from kafka.admin import NewTopic  # Import NewTopic
import json
from flask import Flask, request, jsonify

app = Flask(__name__)
kafka_server = 'localhost:9092'
admin_client = KafkaAdminClient(bootstrap_servers=kafka_server)
producer = KafkaProducer(bootstrap_servers=kafka_server, value_serializer=lambda v: json.dumps(v).encode('utf-8'))

@app.route('/create_topic', methods=['POST'])
def create_topic():
    topic_name = request.json['topic_name']
    # Create a NewTopic object
    new_topic = NewTopic(name=topic_name, num_partitions=1, replication_factor=1)
    admin_client.create_topics([new_topic])
    return jsonify(message=f"Topic '{topic_name}' created.")


@app.route('/delete_topic', methods=['POST'])
def delete_topic():
    topic_name = request.json['topic_name']
    admin_client.delete_topics([topic_name])
    return jsonify(message=f"Topic '{topic_name}' deleted.")

@app.route('/write_to_topic', methods=['POST'])
def write_to_topic():
    topic_name = request.json['topic_name']
    data = request.json['data']
    producer.send(topic_name, data)
    producer.flush()
    return jsonify(message=f"Data sent to topic '{topic_name}'.")

@app.route('/read_from_topic', methods=['GET'])
def read_from_topic():
    topic_name = request.args.get('topic_name')
    consumer = KafkaConsumer(topic_name, bootstrap_servers=kafka_server, auto_offset_reset='earliest', enable_auto_commit=True)
    messages = [msg.value for msg in consumer]
    consumer.close()
    return jsonify(messages)

if __name__ == '__main__':
    app.run(debug=True)
